import math
num = float(input('Digite um número: '))
num_int = math.trunc(num)
print('A parte inteira do número é {}'.format(num_int))

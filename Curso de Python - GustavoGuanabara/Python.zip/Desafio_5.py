n1 = int(input('Digita um número: '))
n_s = int(n1 + 1)
n_a = int(n1 - 1)
print('O número que você digitou é {},\nseu antecessor é {},\nseu sucessor é {}'.format(n1,n_a,n_s))

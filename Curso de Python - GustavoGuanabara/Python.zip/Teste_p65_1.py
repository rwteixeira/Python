# Matriz
dados = [[],[],[]]
while True:




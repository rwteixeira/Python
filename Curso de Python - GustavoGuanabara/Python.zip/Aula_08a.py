import emoji
print(emoji.emojize("Brasil é :globe_with_meridians: "))

# Desafio_83: Crie um programa onde o usuário digite uma expressão qualquer
# que use parênteses. Seu aplicativo deverá analisar se a expressão passada
# está com os parênteses abertos e fechados na ordem correta.
valores = list()
while True:
    v = str(input('Digite a expressão: '))
    valores.append(v)

print(valores)

# LAÇOS DE REPETIÇÃO
# Contagem regressiva para queima de fogos com intevalo de 1s.
from time import sleep
n = 10
for i in range(10,0,-1):
    print(i)
    sleep(1)
print('Queimar fogos!')

nome = input('Digite seu nome: ')
idade = input('Digite sua idade: ')
print('Seu nome é ', nome, ' e sua idade é ',idade)
print(linha)
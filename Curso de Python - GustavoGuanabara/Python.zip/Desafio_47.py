# Mostrar os números pares entre 1 e 50.
for i in range(1,50):
    if (i % 2) == 0:
        print(i)

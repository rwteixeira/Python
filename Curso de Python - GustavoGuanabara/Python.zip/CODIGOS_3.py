import área
comprimento = float(input("Comprimento: "))
largura = float(input("Largura: "))

print(área.área(comprimento, largura))
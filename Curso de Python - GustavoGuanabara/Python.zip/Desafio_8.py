n1 = float(input('Digite uma distância em metros: '))
print('='*60)
cm = n1 * 100
mm = n1 * 1000
print('Você digitou {} metros,\nQue foi convertido para {} cm\nQue foi convertido para {} mm\n'.format(n1,cm, mm))
print('='*60)
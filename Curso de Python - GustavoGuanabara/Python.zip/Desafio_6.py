n1 = int(input('Digite um número: '))
n_d = n1 * 2
n_t = n1 * 3
n_r = pow(n1,(1/2))
print('O número que você digitou é {}\nSeu dobro é {}\nSeu triplo é {}\nSua raiz Quadrada é {:.2f}'.format(n1,n_d,n_t,n_r))

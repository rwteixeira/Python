nome = input('Qual o seu nome? ')
print('É um grande prazer te conhecer,')

n1 = float(input('Entre com a nota do 1º Semestre: '))
n2 = float(input('Entre com a nota do 2º Semestre: '))
print('='*80)
media = (n1 + n2) / 2
print('A nota do 1º Semestre é {:.1f},\nA nota do 2 Semestre é {:.1f},\nA média é {:.1f}'.format(n1,n2,media))
print('='*80)

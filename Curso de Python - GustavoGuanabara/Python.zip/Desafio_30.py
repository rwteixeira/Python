n = int(input('Digite um número inteiro: '))
verificador = n % 2
if verificador == 0:
    print('O número que você digitou é PAR!')
else:
    print('O número que você digitou é ÍMPAR!')
